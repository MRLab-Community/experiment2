=== Better Messages - Voice Messages ===
Contributors: wordplus
Tags: BuddyPress, messages, private message, chat, messaging
Requires at least: 4.0
Tested up to: 6.7
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.2.2 =
* Compatible with Better Messages Mobile App
* Update Freemius SDK to 2.9.0

= 1.2.0 =
* Fully changed recording mechanism for better quality in latest browser versions (change will work in Better Messages 2.3.6 or higher)
* Freemius SDK update to 2.5.12

= 1.1.7 =
* Freemius SDK update to 2.5.10

= 1.1.6 =
* Fixed PHP warnings

= 1.1.5 =
* Compatible with Better Messages 2.0.80

= 1.1.4 =
* Fixed fatal error under some conditions

= 1.1.3 =
* Separating translation domain from main plugin

= 1.1.2 =
* Other improvements for compatibility with Better Messages 2.0

= 1.1.1 =
* Compatible with Better Messages 2.0
* Other bugfixes

= 1.0.9 =
* Added wasm fallback method if configuration of server side is not possible

= 1.0.8 =
* Updated 3rd party libraries

= 1.0.7 =
* Compatibility with Better Messages 1.9.9.163 version
* Minor improvements

= 1.0.6 =
* Minor improvements

= 1.0.5 =
* Minor improvements

= 1.0.4 =
* CSS Improvement (some devices was showing scrollbar)

= 1.0.3 =
* Voice messages now playing when iOS or Android devices muted

= 1.0.2 =
* Activation error fix

= 1.0.1 =
* Prepared to release

= 1.0.0 =
* Initial
